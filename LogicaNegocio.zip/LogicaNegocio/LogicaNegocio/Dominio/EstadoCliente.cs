﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogicaNegocio.Dominio
{
    public class EstadoCliente
    {

        public int Id { get; set; }

        public String Nombre { get; set; }
    }
}
